package com.ayah.app;
import android.appwidget.AppWidgetManager; import android.appwidget.AppWidgetProvider; import android.content.Context; import android.widget.RemoteViews; import java.util.Calendar;
public class AyahWidget extends AppWidgetProvider {
    String[] sabah = {"أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ","اللَّهُمَّ بِكَ أَصْبَحْنَا"};
    String[] quran = {"وَمِنَ اللَّيْلِ فَتَهَجَّدْ","أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ","فَإِنَّ مَعَ الْعُسْرِ يُسْرًا"};
    String[] masaa = {"أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ"};
    String[] lail = {"وَمِنَ اللَّيْلِ فَتَهَجَّدْ بِهِ نَافِلَةً لَّكَ"};
    @Override public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            String ayah = getAyahForNow(); RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_ayah);
            views.setTextViewText(R.id.widget_ayah, ayah); views.setTextViewText(R.id.widget_title, getTitleForNow());
            appWidgetManager.updateAppWidget(id, views);
        }
    }
    String getAyahForNow(){ int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); if (hour >= 6 && hour < 12) return sabah[hour % sabah.length]; else if (hour >= 12 && hour < 18) return quran[hour % quran.length]; else if (hour >= 18 && hour < 19) return masaa[hour % masaa.length]; else return lail[hour % lail.length]; }
    String getTitleForNow(){ int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); if (hour >= 6 && hour < 12) return "آية - أذكار الصباح"; else if (hour >= 12 && hour < 18) return "آية - آيات"; else if (hour >= 18 && hour < 19) return "آية - أذكار المساء"; else return "آية - سكينة الليل"; }
}